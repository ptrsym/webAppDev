<!DOCTYPE html>
<html>
<head>
  <title>PM Searcher</title>
  <meta charset="utf-8">
  <link rel="stylesheet" type="text/css" href="{{asset('css/wp.css')}}">
</head>
<body>
    @yield('content')
    @include('layouts.footer')
</body>
</html>