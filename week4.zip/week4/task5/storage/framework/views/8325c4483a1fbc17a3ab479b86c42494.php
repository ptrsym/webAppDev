<?php $__env->startSection('content'); ?>
<?php if(!empty($name)): ?>
    <h1>Search Results for <?php echo e($name); ?>:</h1>
<?php elseif(!empty($year)): ?>
    <h1>Search Results for <?php echo e($year); ?>:</h1>
<?php elseif(!empty($state)): ?>
    <h1>Search Results for <?php echo e($state); ?>:</h1>
<?php else: ?>
    <h1>Search Results:</h1>
<?php endif; ?>
<table class="bordered">
<thead>
<tr>
    <th>No.</th>
    <th>Name</th>
    <th>From</th>
    <th>To</th>
    <th>Duration</th>
    <th>Party</th>
    <th>State</th>
</tr>
</thead>
<tbody>
    <?php $__empty_1 = true; $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?> 
    <tr>
        <td><?php echo e($pm['index']); ?></td>
        <td><?php echo e($pm['name']); ?></td>
        <td><?php echo e($pm['from']); ?></td>
        <td><?php echo e($pm['to']); ?></td>
        <td><?php echo e($pm['duration']); ?></td>
        <td><?php echo e($pm['party']); ?></td>
        <td><?php echo e($pm['state']); ?></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <tr>
        <td colspan=7>No results found</td>
    </tr>
    <?php endif; ?>
</tbody>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/webAppDev/week4/task5/resources/views/results.blade.php ENDPATH**/ ?>