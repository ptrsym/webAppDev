<div>
    <hr>garf fat cat
</div><?php /**PATH /var/www/html/webAppDev/week4/task4/resources/views/layouts/footer.blade.php ENDPATH**/ ?>